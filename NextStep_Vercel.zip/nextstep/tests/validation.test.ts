import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateAnalysis, validateImage, validateText } from '../server/validation.js';
import { exampleText, exampleAnalysis } from '../src/examples.js';
import analyze from '../api/analyze.js';
import extract from '../api/extract.js';
import type { VercelRequest, VercelResponse } from '@vercel/node';

function response() {
  const state = {status:200,body:null as unknown,headers:{} as Record<string,unknown>};
  const res = {setHeader:(k:string,v:unknown)=>{state.headers[k]=v;},status:(code:number)=>{state.status=code;return res;},json:(body:unknown)=>{state.body=body;return res;}};
  return {state,res:res as unknown as VercelResponse};
}
const req = (body:unknown, method='POST') => ({method,body,headers:{'content-type':'application/json',host:'nextstep.test',origin:'https://nextstep.test'}} as unknown as VercelRequest);
test('example quotes and dates are grounded in the letter',()=>assert.deepEqual(validateAnalysis(exampleAnalysis,exampleText),exampleAnalysis));
test('rejects a quote invented by the model',()=>{const bad=structuredClone(exampleAnalysis);bad.actions[0].evidence='Pay £500 immediately.';assert.throws(()=>validateAnalysis(bad,exampleText),/could not match/);});
test('omits a date absent from the evidence and flags the uncertainty',()=>{const bad=structuredClone(exampleAnalysis);bad.actions[0].deadline='1 December 2026';const safe=validateAnalysis(bad,exampleText);assert.equal(safe.actions[0].deadline,null);assert.ok(safe.uncertainties.some(u=>u.includes('date could not be verified')));});
test('rejects malformed structured output',()=>assert.throws(()=>validateAnalysis({title:'hello'},exampleText),/incomplete/));
test('accepts whitespace-normalised real quotes',()=>{const changed=structuredClone(exampleAnalysis);changed.actions[0].evidence=changed.actions[0].evidence.replaceAll(' ','\n');assert.equal(validateAnalysis(changed,exampleText).actions.length,3);});
test('rejects oversized or empty text',()=>{assert.throws(()=>validateText('hi'));assert.throws(()=>validateText('a'.repeat(24001)));assert.equal(validateText(exampleText),exampleText);});
test('rejects non-image, oversized and disguised payloads',()=>{assert.throws(()=>validateImage('data:text/html;base64,PHNjcmlwdD4='));assert.throws(()=>validateImage('data:image/jpeg;base64,'+'a'.repeat(3500001)));assert.throws(()=>validateImage('data:image/jpeg;base64,PHNjcmlwdD4='));});
test('accepts JPEG signature',()=>assert.equal(validateImage('data:image/jpeg;base64,/9j/AA=='),'data:image/jpeg;base64,/9j/AA=='));
test('API refuses GET and disables caching',async()=>{const {res,state}=response();await analyze(req({},'GET'),res);assert.equal(state.status,405);assert.equal(state.headers['Cache-Control'],'no-store');});
test('API rejects a foreign origin',async()=>{const {res,state}=response();const request=req({text:exampleText});request.headers.origin='https://elsewhere.test';await analyze(request,res);assert.equal(state.status,403);});
test('API validates text before calling the provider',async()=>{const {res,state}=response();await analyze(req({text:'short'}),res);assert.equal(state.status,400);});
test('missing key returns a useful configuration error',async()=>{const key=process.env.OPENAI_API_KEY;delete process.env.OPENAI_API_KEY;try{const {res,state}=response();await analyze(req({text:exampleText}),res);assert.equal(state.status,503);assert.match(JSON.stringify(state.body),/OPENAI_API_KEY/);}finally{if(key)process.env.OPENAI_API_KEY=key;}});
test('mocked AI response passes through real analysis handler and quote validation',async()=>{const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';globalThis.fetch=async()=>new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(exampleAnalysis)}}]}));try{const {res,state}=response();await analyze(req({text:exampleText}),res);assert.equal(state.status,200);assert.deepEqual(state.body,exampleAnalysis);}finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}});
test('extraction handles a photo with no readable text',async()=>{const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';globalThis.fetch=async()=>new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:'NO_READABLE_TEXT'}}]}));try{const {res,state}=response();await extract(req({image:'data:image/jpeg;base64,/9j/AA=='}),res);assert.equal(state.status,400);assert.match(JSON.stringify(state.body),/could not read enough/);}finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}});
test('extraction returns readable text for user review',async()=>{const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';globalThis.fetch=async()=>new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:exampleText}}]}));try{const {res,state}=response();await extract(req({image:'data:image/jpeg;base64,/9j/AA=='}),res);assert.equal(state.status,200);assert.deepEqual(state.body,{text:exampleText});}finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}});
test('analysis automatically retries an invented quote and keeps validation strict',async()=>{
 const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';
 let calls=0;const bad=structuredClone(exampleAnalysis);bad.actions[0].evidence='This sentence is not in the letter.';
 globalThis.fetch=async()=>{calls++;return new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(calls===1?bad:exampleAnalysis)}}]}));};
 try{const {res,state}=response();await analyze(req({text:exampleText}),res);assert.equal(state.status,200);assert.equal(calls,2);assert.deepEqual(state.body,exampleAnalysis);}
 finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}
});
test('analysis refuses a second ungrounded result instead of showing it',async()=>{
 const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';
 let calls=0;const bad=structuredClone(exampleAnalysis);bad.actions[0].evidence='This sentence is not in the letter.';
 globalThis.fetch=async()=>{calls++;return new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(bad)}}]}));};
 try{const {res,state}=response();await analyze(req({text:exampleText}),res);assert.equal(state.status,502);assert.equal(calls,2);}
 finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}
});
test('a missing optional deadline cannot discard the explanation',()=>{
 const x=structuredClone(exampleAnalysis);delete (x.actions[0] as Partial<typeof x.actions[0]>).deadline;
 const safe=validateAnalysis(x,exampleText);assert.equal(safe.actions.length,3);assert.equal(safe.actions[0].deadline,null);
});
test('blank and literal-null dates are treated as no date',()=>{
 for(const date of ['', 'null', 'NULL']){const x=structuredClone(exampleAnalysis);x.actions[0].deadline=date;assert.equal(validateAnalysis(x,exampleText).actions[0].deadline,null);}
});
test('an incomplete action is omitted and visibly flagged, without discarding the summary',()=>{
 const x=structuredClone(exampleAnalysis);x.actions[0].detail='';const safe=validateAnalysis(x,exampleText);
 assert.equal(safe.summary,exampleAnalysis.summary);assert.equal(safe.actions.length,2);assert.ok(safe.uncertainties.some(u=>u.includes('step was left out')));
});
test('an information-only letter can have no actions or reply',()=>{
 const x=structuredClone(exampleAnalysis);x.actions=[];x.reply='';assert.equal(validateAnalysis(x,exampleText).actions.length,0);
});
test('provider request uses strict structured output with every action key required',async()=>{
 const oldFetch=globalThis.fetch;const key=process.env.OPENAI_API_KEY;process.env.OPENAI_API_KEY='unit-test-not-a-real-key';
 let body:any;
 globalThis.fetch=async(_url,init)=>{body=JSON.parse(String(init?.body));return new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify(exampleAnalysis)}}]}));};
 try{const {res,state}=response();await analyze(req({text:exampleText}),res);assert.equal(state.status,200);
  assert.equal(body.response_format.type,'json_schema');assert.equal(body.response_format.json_schema.strict,true);
  const schema=body.response_format.json_schema.schema;assert.equal(schema.additionalProperties,false);
  assert.deepEqual(schema.properties.actions.items.required,['title','detail','evidence','deadline']);
  assert.deepEqual(schema.properties.actions.items.properties.deadline.type,['string','null']);
 }finally{globalThis.fetch=oldFetch;if(key)process.env.OPENAI_API_KEY=key;else delete process.env.OPENAI_API_KEY;}
});
