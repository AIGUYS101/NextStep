import type { Analysis } from './types';
export const exampleText = `EXAMPLE LETTER — FICTIONAL, FOR DEMONSTRATION ONLY

Meadow Community Learning
9 November 2026

Dear Alex,

Thank you for your interest in our free Digital Confidence course. We are pleased to offer you a place, subject to confirmation of your attendance.

Please confirm that you would like to attend by 20 November 2026. You can confirm by emailing learning@example.org and quoting reference DC-204.

Your first session will be held on 26 November 2026 at 10:00am at Meadow Community Centre. Please bring this letter with you.

If you require step-free access, a hearing loop, or information in another format, please tell us when you confirm your place so that we can discuss arrangements with you.

If we do not hear from you by 20 November 2026, we may offer your place to someone on the waiting list.

Kind regards,
The Community Learning Team`;
export const exampleAnalysis: Analysis = {
  title: 'You have a place on a free course',
  summary: 'You have been offered a place on a free computer skills course. You need to reply by 20 November 2026 to keep your place.',
  meaning: ['The course is free. It is called Digital Confidence.', 'Your place is not confirmed yet. They need you to say you want to attend.', 'The first session is on 26 November 2026 at 10:00am, at Meadow Community Centre.'],
  actions: [
    {title:'Confirm you want your place', detail:'Email learning@example.org. Say you want to attend and include reference DC-204.', evidence:'Please confirm that you would like to attend by 20 November 2026. You can confirm by emailing learning@example.org and quoting reference DC-204.', deadline:'20 November 2026'},
    {title:'Tell them about any access needs', detail:'When you reply, mention any support you would like to discuss. You do not need to share more than you are comfortable with.', evidence:'If you require step-free access, a hearing loop, or information in another format, please tell us when you confirm your place so that we can discuss arrangements with you.', deadline:null},
    {title:'Bring the letter to your first session', detail:'Your first session is at Meadow Community Centre on 26 November 2026 at 10:00am.', evidence:'Your first session will be held on 26 November 2026 at 10:00am at Meadow Community Centre. Please bring this letter with you.', deadline:'26 November 2026'}
  ],
  uncertainties:['The letter does not give the full address of Meadow Community Centre.', 'It does not say how long each session lasts or how many sessions there are.'],
  questions:['What is the full address of the community centre?', 'How long is each session, and how many sessions are there?'],
  reply:'Dear Community Learning Team,\n\nThank you for offering me a place on the free Digital Confidence course. I would like to confirm that I will attend. My reference is DC-204.\n\nPlease could you confirm the full address of Meadow Community Centre and how long the sessions last?\n\nKind regards,\n[Your name]'
};
