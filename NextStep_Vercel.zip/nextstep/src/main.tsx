import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowRight, ArrowUpRight, Check, ChevronDown, Camera, CheckCircle2, Clipboard, Copy, FileText, HeartHandshake, ImagePlus, LoaderCircle, LockKeyhole, MessageSquareText, RotateCcw, ShieldCheck, Sparkles, Upload, Volume2, X, ZoomIn, CircleHelp, ArrowLeft, Square, Clock3 } from 'lucide-react';
import { exampleAnalysis, exampleText } from './examples';
import type { Analysis } from './types';
import './styles.css';

type Mode = 'paste'|'upload'|'camera';
type Busy = 'extract'|'analyze'|null;
async function post<T>(path:string, body:unknown, signal:AbortSignal):Promise<T> {
  const response = await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal});
  const result = await response.json().catch(()=>null);
  if (!response.ok) throw new Error(result?.error || 'The service is not available here yet. Please try the example letter.');
  return result as T;
}
async function prepareImage(file: File): Promise<string> {
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Please choose a JPEG, PNG or WebP image. For HEIC photos, save or share them as JPEG first.');
  if (file.size > 20 * 1024 * 1024) throw new Error('Please choose a photo smaller than 20 MB.');
  const bitmap = await createImageBitmap(file);
  try {
    const ratio = Math.min(1,1800 / Math.max(bitmap.width,bitmap.height));
    const canvas = document.createElement('canvas'); canvas.width = Math.round(bitmap.width * ratio); canvas.height = Math.round(bitmap.height * ratio);
    const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('This browser could not prepare the photo. Please paste the text instead.');
    ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const image = canvas.toDataURL('image/jpeg',0.86);
    if (image.length > 3500000) throw new Error('This photo is too detailed to send. Please crop it to the letter and try again.');
    return image;
  } finally { bitmap.close(); }
}
function App() {
  const [mode,setMode] = useState<Mode>('paste');
  const [text,setText] = useState('');
  const [image,setImage] = useState<string|null>(null);
  const [filename,setFilename] = useState('');
  const [busy,setBusy] = useState<Busy>(null);
  const [preparing,setPreparing] = useState(false);
  const [error,setError] = useState('');
  const [result,setResult] = useState<Analysis|null>(null);
  const [resultSource,setResultSource] = useState('');
  const [demo,setDemo] = useState(false);
  const [ocrReview,setOcrReview] = useState(false);
  const [checked,setChecked] = useState<number[]>([]);
  const [reply,setReply] = useState('');
  const [copied,setCopied] = useState(false);
  const [large,setLarge] = useState(false);
  const [contrast,setContrast] = useState(false);
  const [speech,setSpeech] = useState(false);
  const [speechAvailable,setSpeechAvailable] = useState(false);
  const [notice,setNotice] = useState('');
  const [help,setHelp] = useState(false);
  const [consent,setConsent] = useState(false);
  const [dragging,setDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const helpCloseRef = useRef<HTMLButtonElement>(null);
  const helpTriggerRef = useRef<HTMLButtonElement>(null);
  const controller = useRef<AbortController|null>(null);
  const imageSequence = useRef(0);
  const pending = !!busy || preparing;
  useEffect(()=>{setSpeechAvailable('speechSynthesis' in window);return ()=>{controller.current?.abort();if ('speechSynthesis' in window) window.speechSynthesis.cancel();};},[]);
  useEffect(()=>{document.documentElement.classList.toggle('large-text',large);document.documentElement.classList.toggle('high-contrast',contrast);},[large,contrast]);
  useEffect(()=>{ if (help) helpCloseRef.current?.focus(); },[help]);
  function clearSpeech() {if ('speechSynthesis' in window) window.speechSynthesis.cancel();setSpeech(false);}
  function reset() {
    imageSequence.current++;controller.current?.abort();controller.current=null;clearSpeech();setText('');setImage(null);setResult(null);setResultSource('');setError('');setBusy(null);setPreparing(false);setOcrReview(false);setDemo(false);setChecked([]);setReply('');setNotice('');setConsent(false);setMode('paste');
  }
  function editText(value:string) { setText(value);setDemo(false);setError(''); }
  function showExample() {
    clearSpeech();setText(exampleText);setMode('paste');setImage(null);setDemo(true);setOcrReview(false);setError('');setNotice('Example letter loaded. Choose “Help me understand” to explore a prepared demonstration.');editorRef.current?.focus();
  }
  async function chooseFile(file?:File) {
    if (!file || pending) return;
    const sequence = ++imageSequence.current;
    setError('');setNotice('');setPreparing(true);
    try {const prepared = await prepareImage(file);if(sequence!==imageSequence.current)return;setImage(prepared);setFilename(file.name);setText('');setDemo(false);setOcrReview(false);}
    catch(e) {if(sequence===imageSequence.current)setError(e instanceof Error?e.message:'This photo could not be opened. Please try another photo.');}
    finally {if(sequence===imageSequence.current)setPreparing(false);}
  }
  async function submit() {
    if (pending) return;
    setError('');setNotice('');clearSpeech();
    if (demo && text === exampleText) {
      setResult(exampleAnalysis);setResultSource(text);setReply(exampleAnalysis.reply);setChecked([]);return;
    }
    if (!consent) {setError('Please confirm you are happy to send this content to the AI service.');return;}
    const request = new AbortController();controller.current=request;
    const timeout = window.setTimeout(()=>request.abort(),55000);
    try {
      if (mode !== 'paste' && image && !ocrReview) {
        setBusy('extract');
        const data = await post<{text:string}>('/api/extract',{image},request.signal);
        setText(data.text);setOcrReview(true);setMode('paste');setNotice('Photo read successfully. Check the text, then choose “Explain this letter”.');
        window.setTimeout(()=>editorRef.current?.focus(),0);
      } else {
        if(text.trim().length < 30) throw new Error('Please add at least 30 characters from your letter.');
        setBusy('analyze');
        const data = await post<Analysis>('/api/analyze',{text},request.signal);
        setResult(data);setResultSource(text);setReply(data.reply);setChecked([]);
      }
    } catch(e) { if (!request.signal.aborted || controller.current===request) setError(e instanceof DOMException && e.name==='AbortError' ? 'This request took too long. Please try again or use a shorter section.' : e instanceof Error?e.message:'Something went wrong. Please try again.'); }
    finally {window.clearTimeout(timeout);if(controller.current===request){setBusy(null);controller.current=null;}}
  }
  useEffect(()=>{if(result){resultRef.current?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});resultRef.current?.focus();}},[result]);
  async function copyReply() { try {await navigator.clipboard.writeText(reply);setCopied(true);setNotice('Reply copied.');window.setTimeout(()=>setCopied(false),2500);} catch {setNotice('Copy was unavailable. Select the reply text and copy it using your device.');} }
  function readAloud() {
    if(speech) {clearSpeech();return;}
    if(!result || !speechAvailable)return;
    const content = [result.title,result.summary,...result.meaning,...result.actions.map(a=>`${a.title}. ${a.detail}${a.deadline?`. Date in letter: ${a.deadline}`:''}`),...result.uncertainties].join('. ');
    const utterance = new SpeechSynthesisUtterance(content);utterance.lang='en-GB';utterance.rate=0.88;utterance.onend=()=>setSpeech(false);utterance.onerror=()=>{setSpeech(false);setNotice('Read aloud is unavailable on this device.');};window.speechSynthesis.cancel();window.speechSynthesis.speak(utterance);setSpeech(true);
  }
  const photoToRead = mode !== 'paste' && image && !ocrReview;
  const canSubmit = !pending && (demo || consent) && (mode === 'paste' ? text.trim().length >= 30 : !!image);
  const step = result?3:ocrReview?2:1;
  return <>
    <a className="skip-link" href="#workspace">Skip to letter tool</a>
    <header className="header"><div className="header-inner">
      <a href="#" className="brand" aria-label="NextStep home" onClick={e=>{e.preventDefault();if(!pending)reset();}}><span className="brand-mark"><ArrowRight size={23}/></span>NextStep<span className="beta">BETA</span></a>
      <nav aria-label="Accessibility and help"><button className="utility" aria-pressed={large} onClick={()=>setLarge(!large)}><ZoomIn size={17}/><span>Larger text</span></button><button className="contrast-toggle" aria-pressed={contrast} aria-label="Toggle high contrast" title="Toggle high contrast" onClick={()=>setContrast(!contrast)}><span/></button><span className="nav-divider"/><button className="utility" ref={helpTriggerRef} onClick={()=>setHelp(true)}><CircleHelp size={18}/><span>How it works</span></button></nav>
    </div></header>
    <main>
      <section className={`hero ${result?'hero-small':''}`} aria-labelledby="hero-title">
        <div className="eyebrow"><span/> A LITTLE CLARITY. A WAY FORWARD.</div>
        <h1 id="hero-title">Big words.<br className="mobile-break"/> <em>Clear next steps.</em></h1>
        <p>Letters can be confusing. Let’s make yours easier to understand,<br className="desktop-break"/> so you can decide what to do next.</p>
        <div className="hero-proof"><span><CheckCircle2 size={15}/> Plain English</span><span><CheckCircle2 size={15}/> One step at a time</span><span><CheckCircle2 size={15}/> No account needed</span></div>
        <div className="hero-decoration" aria-hidden="true"><ArrowUpRight/></div>
      </section>
      <div className="app-shell" id="workspace">
        <div className="journey" aria-label="Your progress"><span className={step===1?'current':''} aria-current={step===1?'step':undefined}><b>{step>1?<Check size={12}/>:1}</b>Add your letter</span><i/><span className={step===2?'current':''} aria-current={step===2?'step':undefined}><b>{step>2?<Check size={12}/>:2}</b>Check the words</span><i/><span className={step===3?'current':''} aria-current={step===3?'step':undefined}><b>3</b>Your next steps</span></div>
        {!result ? <div className="workspace-grid">
          <section className="input-panel" aria-labelledby="input-heading">
            <div className="panel-heading"><div><span className="section-kicker">LET’S START HERE</span><h2 id="input-heading">{ocrReview?'Check your letter’s text':'What does your letter say?'}</h2></div><span className="panel-icon"><FileText size={23}/></span></div>
            <p className="panel-description">{ocrReview?'Your photo has been read. Check the text below, then choose “Explain this letter” to get your next steps.':'Paste the words, upload a photo, or take one now.'}</p>
            <div className="input-tabs" role="group" aria-label="Choose how to add your letter">
              <button aria-pressed={mode==='paste'} className={mode==='paste'?'active':''} disabled={pending} onClick={()=>setMode('paste')}><Clipboard size={17}/>Paste text</button>
              <button aria-pressed={mode==='upload'} className={mode==='upload'?'active':''} disabled={pending} onClick={()=>{setMode('upload');setOcrReview(false);}}><Upload size={17}/>Upload photo</button>
              <button aria-pressed={mode==='camera'} className={mode==='camera'?'active':''} disabled={pending} onClick={()=>{setMode('camera');setOcrReview(false);}}><Camera size={17}/>Take photo</button>
            </div>
            {mode==='paste'?<div className="text-entry"><label htmlFor="letter-text">{ocrReview?'Text read from your photo':'Your letter’s text'}</label><textarea ref={editorRef} id="letter-text" value={text} maxLength={24000} disabled={pending} onChange={e=>editText(e.target.value)} placeholder={'Dear…\n\nPaste your letter or message here.\nWe’ll help you make sense of it.'} aria-describedby="text-hint"/><div className="textarea-footer" id="text-hint"><span>{ocrReview?'Review and edit anything that looks wrong.':'You can remove personal details before you start.'}</span><span>{text.length.toLocaleString()} / 24,000</span></div></div>:
              <div className={`upload-zone ${dragging?'dragging':''}`} onDragOver={e=>{e.preventDefault();if(!pending)setDragging(true);}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);if(!pending)void chooseFile(e.dataTransfer.files[0]);}}>
                {image ? <><img src={image} alt="Your uploaded letter, ready for reading"/><span className="filename">{filename}</span><button className="secondary" disabled={pending} onClick={()=>{setImage(null);setText('');setOcrReview(false);}}>Remove photo</button></> : <><span className="upload-icon">{mode==='camera'?<Camera size={31}/>:<ImagePlus size={31}/>}</span><h3>{mode==='camera'?'A photo is a good place to start':'Drop your letter’s photo here'}</h3><p>{mode==='camera'?'Lay the letter flat and make sure all the words are in view.':'Or choose an image from your phone or computer.'}</p><button className="secondary" disabled={pending} onClick={()=>mode==='camera'?cameraRef.current?.click():fileRef.current?.click()}>{mode==='camera'?<Camera size={17}/>:<Upload size={17}/>} {mode==='camera'?'Open camera':'Choose a photo'}</button><small>JPEG, PNG or WebP · up to 20 MB<br/>{mode==='camera'?'On supported phones, this opens the camera. Other devices may show a file picker.':'One page at a time · use a clear, well-lit photo'}</small></>}
              </div>}
            <input hidden ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>{void chooseFile(e.target.files?.[0]);e.target.value='';}}/>
            <input hidden ref={cameraRef} type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={e=>{void chooseFile(e.target.files?.[0]);e.target.value='';}}/>
            {!demo&&<label className="consent"><input type="checkbox" checked={consent} disabled={pending} onChange={e=>setConsent(e.target.checked)}/><span>I’m happy to send this {photoToRead?'photo':'text'} to OpenAI to help read and explain it. <button className="text-button" onClick={e=>{e.preventDefault();setHelp(true);}}>About my information</button></span></label>}
            {demo&&<div className="demo-label"><Sparkles size={16}/><span>Example mode · fictional letter and prepared explanation. No AI request is made.</span></div>}
            {error&&<div className="error-box" role="alert"><CircleHelp size={20}/><span>{error}</span></div>}
            <button className="primary analyze-button" disabled={!canSubmit} onClick={()=>void submit()}>{pending?<><LoaderCircle size={19} className="spin"/>{preparing?'Preparing your photo…':busy==='extract'?'Reading your photo…':'Making things clearer…'}</>:<>{photoToRead?'Read my photo':ocrReview?'Explain this letter':'Help me understand'}<ArrowRight size={20}/></>}</button>
            <div className="under-button"><LockKeyhole size={13}/><span>No account. No documents saved by this app.</span></div>
          </section>
          <aside className="side-column">
            <div className="reassurance-card"><div className="little-symbol" aria-hidden="true"><HeartHandshake size={25}/></div><h2>You don’t have to<br/>figure it out alone.</h2><p>We’ll turn the complicated bits into something you can work with.</p><ul><li><span><FileText size={18}/></span><div><strong>Understand the important bits</strong><p>A short explanation in everyday words.</p></div></li><li><span><CheckCircle2 size={18}/></span><div><strong>Know what to do next</strong><p>Small steps, with dates from your letter.</p></div></li><li><span><MessageSquareText size={18}/></span><div><strong>Find the words to reply</strong><p>A draft you can edit and make your own.</p></div></li></ul><div className="human-note"><ShieldCheck size={17}/><span>Your letter stays the source.<br/>You stay in control.</span></div></div>
            <button className="example-card" onClick={showExample} disabled={pending}><span className="example-icon"><Sparkles size={21}/></span><span><strong>Just looking around?</strong><small>Try an example letter</small></span><ArrowUpRight size={21}/></button>
          </aside>
        </div>:<section className="results" ref={resultRef} tabIndex={-1} aria-labelledby="result-title">
          <div className="results-topline"><button className="text-button back-button" onClick={()=>{clearSpeech();setResult(null);setNotice('');}}><ArrowLeft size={17}/> Back to your letter</button><span className={demo?'demo-pill':'live-pill'}>{demo?<Sparkles size={13}/>:<CheckCircle2 size={13}/>} {demo?'Prepared example':'AI explanation'}</span></div>
          <div className="result-intro"><div><span className="section-kicker">A LITTLE CLEARER, ALREADY</span><h2 id="result-title">{result.title}</h2><p>{result.summary}</p></div><button className="secondary read-button" disabled={!speechAvailable} title={!speechAvailable?'Read aloud is not supported in this browser':undefined} onClick={readAloud}>{speech?<Square size={17}/>:<Volume2 size={18}/>} {speech?'Stop reading':'Read aloud'}</button></div>
          <div className="result-columns"><div className="result-main">
            <section className="result-card"><h3><FileText size={19}/> What it means</h3><ul className="meaning-list">{result.meaning.map((m,i)=><li key={i}>{m}</li>)}</ul></section>
            <section className="result-card"><div className="card-title-row"><h3><CheckCircle2 size={19}/> Your next steps</h3><span className="completion-count">{checked.length} of {result.actions.length} done</span></div><p className="muted small">Go at your own pace. Tick a step when you’ve done it.</p>{result.actions.length===0&&<p>No specific action was identified in this text. Check the original and contact the sender if you are unsure.</p>}
              <div className="action-list">{result.actions.map((action,i)=><article key={i} className={`action-item ${checked.includes(i)?'done':''}`}><label className="action-check"><input type="checkbox" checked={checked.includes(i)} onChange={()=>setChecked(prev=>prev.includes(i)?prev.filter(n=>n!==i):[...prev,i])}/><span><strong>{action.title}</strong></span></label><div className="action-body"><p>{action.detail}</p>{action.deadline&&<span className="date-chip"><Clock3 size={13}/> Date in letter: {action.deadline}</span>}<details className="evidence"><summary>Show me where it says that <ChevronDown size={14}/></summary><blockquote>{action.evidence}</blockquote></details></div></article>)}</div>
            </section>
            <section className="result-card reply-card"><div className="card-title-row"><h3><MessageSquareText size={19}/> A starting point for your reply</h3><span className="editable-tag">EDITABLE</span></div><p className="muted small">Change anything you like. Check the details and add your name before sending.</p><label className="sr-only" htmlFor="reply">Edit your reply</label><textarea id="reply" value={reply} onChange={e=>setReply(e.target.value)} rows={10}/><button className="secondary" onClick={()=>void copyReply()}>{copied?<Check size={16}/>:<Copy size={16}/>} {copied?'Copied':'Copy reply'}</button><span className="reply-note">Nothing is sent automatically.</span></section>
          </div><aside className="result-side">
            <section className="uncertain-card"><span className="little-symbol"><CircleHelp size={22}/></span><h3>Worth checking</h3><p>Some things may need a little more information.</p>{result.uncertainties.length?<ul>{result.uncertainties.map((u,i)=><li key={i}>{u}</li>)}</ul>:<p>No missing details were flagged. Please still check the original letter.</p>}{result.questions.length>0&&<><h4>You could ask the sender</h4><ul>{result.questions.map((q,i)=><li key={i}>{q}</li>)}</ul></>}</section>
            <section className="source-card"><ShieldCheck size={20}/><h3>Always check your letter</h3><p>AI can make mistakes. This is help with understanding, not professional advice. Confirm important details with the sender using contact details you trust.</p><details><summary>View the original text <ChevronDown size={14}/></summary><pre>{resultSource}</pre></details></section>
            <button className="secondary start-over" onClick={reset}><RotateCcw size={16}/> Start a new letter</button>
          </aside></div>
        </section>}
        <div className="trust-strip"><span><ShieldCheck size={17}/> Built around your understanding</span><span><LockKeyhole size={17}/> No documents saved by this app</span><span><HeartHandshake size={17}/> You choose your next step</span></div>
      </div>
      <section className="bottom-note"><p>Understanding shouldn’t be a barrier.</p><span>For the letters, messages and moments that could use a little clarity.</span></section>
    </main>
    <footer><a className="footer-brand" href="#">NextStep <ArrowUpRight size={15}/></a><span>A CTRL-V hackathon prototype. Built to make access easier.</span><button className="text-button" onClick={()=>setHelp(true)}>Privacy & limitations</button></footer>
    <div className="sr-only" role="status" aria-live="polite">{notice}</div>
    {notice&&!result&&<div className="toast" role="status"><CheckCircle2 size={18}/><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Dismiss notification"><X size={16}/></button></div>}
    {help&&<div className="modal-overlay" onClick={e=>{if(e.target===e.currentTarget){setHelp(false);helpTriggerRef.current?.focus();}}}><section className="help-modal" role="dialog" aria-modal="true" aria-labelledby="help-title" onKeyDown={e=>{if(e.key==='Escape'){setHelp(false);helpTriggerRef.current?.focus();} if(e.key==='Tab'){e.preventDefault();helpCloseRef.current?.focus();}}}><button ref={helpCloseRef} className="modal-close" aria-label="Close help" onClick={()=>{setHelp(false);helpTriggerRef.current?.focus();}}><X size={22}/></button><span className="section-kicker">A LITTLE HELP</span><h2 id="help-title">Your letter. Made clearer.</h2><ol><li><strong>Add your letter.</strong> Paste text, upload a photo or use your phone’s camera.</li><li><strong>Check the words.</strong> For photos, review the extracted text before continuing. For pasted text, check it before you submit.</li><li><strong>Take your next step.</strong> Read the explanation, check the source quotes and edit a reply.</li></ol><h3>About your information</h3><p>Live requests send your text or photo to OpenAI through this app’s server. This app has no document database and does not deliberately log document contents. Content remains in this tab until you clear it or leave. OpenAI may retain requests under its API data policies; hosting infrastructure may also keep request metadata.</p><p>Remove personal details you don’t need to share. Please use fictional documents when trying the prototype. We cannot promise zero retention by service providers.</p><h3>What to keep in mind</h3><p>AI and photo reading can make mistakes. Check names, dates, amounts and anything urgent against the original. Quotes are checked against the text, but that does not guarantee the explanation is correct. NextStep explains wording; it does not replace medical, legal or financial advice.</p><p>Read aloud uses your browser or device’s speech service. Available voices and processing depend on your device. Example mode uses a fictional letter and a prepared answer; it does not call AI.</p></section></div>}
  </>;
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);
