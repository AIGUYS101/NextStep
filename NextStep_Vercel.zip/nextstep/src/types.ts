export type Action = { title: string; detail: string; evidence: string; deadline: string | null };
export type Analysis = { title: string; summary: string; meaning: string[]; actions: Action[]; uncertainties: string[]; questions: string[]; reply: string };
