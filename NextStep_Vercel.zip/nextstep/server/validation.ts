import type { Analysis } from '../src/types.js';
export class RequestError extends Error { constructor(message: string, public status = 400) { super(message); } }
export const normalize = (s: string) => s.normalize('NFKC').replace(/\s+/g, ' ').trim().toLowerCase();
function str(v: unknown, max = 4000): v is string { return typeof v === 'string' && v.length > 0 && v.length <= max; }
function strings(v: unknown): v is string[] { return Array.isArray(v) && v.length <= 12 && v.every(s => str(s)); }
export function validateAnalysis(value: unknown, source: string): Analysis {
  const x = value as Analysis;
  if (!x || !str(x.title, 200) || !str(x.summary) || !strings(x.meaning) || !strings(x.uncertainties) || !strings(x.questions) || typeof x.reply !== 'string' || x.reply.length > 8000 || !Array.isArray(x.actions) || x.actions.length > 12) throw new RequestError('The explanation was incomplete. Please try again.', 502);
  const result: Analysis = { ...x, uncertainties: [...x.uncertainties], actions: [] };
  const warn = (message: string) => { if (!result.uncertainties.includes(message)) result.uncertainties.push(message); };
  const text = normalize(source);
  for (const a of x.actions) {
    // A malformed suggested step must not discard a usable explanation.
    // Omit it explicitly rather than inventing its missing content or evidence.
    if (!a || !str(a.title, 200) || !str(a.detail) || !str(a.evidence)) {
      warn('A suggested step was left out because its explanation or supporting quote was missing. Check the original letter for any actions.');
      continue;
    }
    if (!text.includes(normalize(a.evidence))) throw new RequestError('We could not match an action to the original wording. Please try again or use a shorter section of your letter.', 502);
    // Missing, blank and literal-null optional dates all mean no date. Other
    // invalid dates are omitted with a visible uncertainty, never fabricated.
    const rawDate: unknown = a.deadline;
    let deadline: string | null = null;
    if (rawDate != null && rawDate !== '' && !(typeof rawDate === 'string' && rawDate.trim().toLowerCase() === 'null')) {
      if (str(rawDate, 200) && normalize(a.evidence).includes(normalize(rawDate))) deadline = rawDate;
      else warn('A suggested date could not be verified in its source quote. Please check dates in the original letter.');
    }
    result.actions.push({ title: a.title, detail: a.detail, evidence: a.evidence, deadline });
  }
  return result;
}
export function validateText(value: unknown): string {
  if (typeof value !== 'string' || value.trim().length < 30) throw new RequestError('Please add at least 30 characters from your letter.');
  if (value.length > 24000) throw new RequestError('This letter is a little long. Please use a section of up to 24,000 characters.');
  return value.trim();
}
export function validateImage(value: unknown): string {
  if (typeof value !== 'string' || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+=*$/.test(value)) throw new RequestError('Please upload a JPEG, PNG or WebP photo.');
  if (value.length > 3_500_000) throw new RequestError('This photo is too large. Please try a smaller image.',413);
  const encoded = value.slice(value.indexOf(',')+1);
  const bytes = Buffer.from(encoded,'base64');
  const jpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const png = bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const webp = bytes.toString('ascii',0,4) === 'RIFF' && bytes.toString('ascii',8,12) === 'WEBP';
  const declaredType = value.slice(0,value.indexOf(';'));
  if (!(declaredType === 'data:image/jpeg' && jpeg || declaredType === 'data:image/png' && png || declaredType === 'data:image/webp' && webp)) throw new RequestError('The image contents do not match its file type. Please choose another photo.');
  return value;
}
