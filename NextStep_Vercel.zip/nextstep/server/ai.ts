import type { VercelRequest, VercelResponse } from '@vercel/node';
import { RequestError } from './validation.js';
import { analysisResponseFormat } from './schema.js';
type Content = string | Array<{type:'text';text:string} | {type:'image_url';image_url:{url:string;detail:'high'}}>;
export async function complete(system: string, content: Content, json = false, timeoutMs = 45000): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new RequestError('Live AI is not connected yet. Try the example letter, or ask the app owner to add OPENAI_API_KEY in Vercel.',503);
  const response = await fetch('https://api.openai.com/v1/chat/completions',{
    method:'POST', headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},
    signal:AbortSignal.timeout(timeoutMs),
    body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4.1-mini',temperature:0.1,max_tokens:json ? 4000 : 6000,messages:[{role:'system',content:system},{role:'user',content}],...(json ? {response_format:analysisResponseFormat}:{})})
  });
  if (!response.ok) { await response.body?.cancel(); throw new RequestError(response.status === 429 ? 'The AI service is busy or its usage limit has been reached. Please try again later.' : 'The AI service could not process this request. Please try again later.',502); }
  const data = await response.json();
  if (data.choices?.[0]?.finish_reason !== 'stop' || typeof data.choices?.[0]?.message?.content !== 'string') throw new RequestError('The AI could not finish reading this letter. Try a shorter section or a clearer photo.',502);
  return data.choices[0].message.content;
}
export function begin(req: VercelRequest, res: VercelResponse): boolean {
  res.setHeader('Cache-Control','no-store');
  if (req.method !== 'POST') { res.setHeader('Allow','POST'); res.status(405).json({error:'Please use POST for this request.'}); return false; }
  if (!req.headers['content-type']?.includes('application/json')) { res.status(415).json({error:'Please send JSON.'}); return false; }
  // Browser-origin check reduces cross-site abuse; it is not a substitute for a durable rate limiter.
  const origin = req.headers.origin;
  const host = req.headers.host;
  if (origin && host) {
    try { if (new URL(origin).host !== host) { res.status(403).json({error:'This request must come from NextStep.'}); return false; } }
    catch { res.status(403).json({error:'Invalid request origin.'}); return false; }
  }
  return true;
}
export function fail(res: VercelResponse, error: unknown) {
  if (error instanceof RequestError) return res.status(error.status).json({error:error.message});
  // No document text, image, secret, or provider payload is written to application logs.
  return res.status(502).json({error:'We could not finish this request. Please try again. If it keeps happening, try a shorter section of your letter.'});
}
