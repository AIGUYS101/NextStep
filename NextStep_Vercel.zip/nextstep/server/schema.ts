// Constrain the provider response itself, rather than relying on a prompt to
// produce the action keys that the interface needs.
const text = { type: 'string' };
const textList = { type: 'array', items: text };
export const analysisResponseFormat = {
  type: 'json_schema',
  json_schema: {
    name: 'letter_explanation',
    strict: true,
    schema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        title: text,
        summary: text,
        meaning: textList,
        actions: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              title: text,
              detail: text,
              evidence: text,
              deadline: { type: ['string', 'null'] },
            },
            required: ['title', 'detail', 'evidence', 'deadline'],
          },
        },
        uncertainties: textList,
        questions: textList,
        reply: text,
      },
      required: ['title', 'summary', 'meaning', 'actions', 'uncertainties', 'questions', 'reply'],
    },
  },
} as const;
